GloryCast Switch - see your cameras on a phone and tap one to send it live (works with OBS 28 or later)

1. In OBS: Tools > WebSocket Server Settings > tick Enable WebSocket server > Show Connect Info, note the password.
2. Mac: open the GloryCast Switch app (see "Mac app" below). Your browser opens with the phone links. No Terminal needed.
   Windows: double-click "Start GloryCast Switch (Windows).bat". A black window shows the phone links.
   Leave that window open during service.
   If Windows asks about the firewall (for this window or for OBS), allow Private networks.
   If the Mac asks to let it find devices on your local network, click Allow (one time).
3. On your phone (same Wi-Fi as the laptop), open  http://glorycast-switch.local:7790/  in Safari (iPhone) or Chrome.
   This link stays the same every week, even when the laptop's number changes. Type the OBS password once.
   If it does not open (some Android phones), use the number link shown in the black window instead,
   for example http://192.168.0.10:7790/
   Hold the phone sideways: Preview and Live big on top, cameras below, CUT and AUTO down the right.
   iPhone tip: with the glorycast-switch.local link open, Share > Add to Home Screen opens it full screen like an app.
4. Every OBS scene shows as a tile with a moving picture.
   Tap = Live: tap a camera and it goes straight to the stream.
   Preview first: a tap lines the camera up (green) on the phone, then CUT or AUTO sends it live (red).
   Change with: Cut or Fade, and the fade length (0.3 s up to 20 s, or Other... to type your own).

Mac app (no Terminal)
- Unzip GloryCast-Switch-Mac-app.zip in Finder (double-click it in Downloads). Do not open it from Google Drive:
  Drive turns the app into a plain folder.
- Drag "GloryCast Switch" into Applications.
- First time only: right-click it > Open > Open (the Mac does not know the app yet). After that, a normal click opens it.
- If the Mac asks to let it find devices on your local network, click Allow.
- Click the app any time: it starts Switch in the background and opens it in the browser. Clicking again just reopens it.
- To stop it: Settings > Stop GloryCast Switch (on the Mac's browser only). Phones lose Switch until you open the app again.
- The app needs Python 3. If it says Python is missing, click Get Python, install it, then open the app again.
- The old "Start GloryCast Switch (Mac).command" still works if you ever need it.

Android app (no computer program needed, only OBS)
- Install GloryCast-Switch.apk on the Android phone (allow "install unknown apps" for Files or WhatsApp when asked).
- In OBS: Tools > WebSocket Server Settings > Enable WebSocket server (port 4455).
- Phone on the same Wi-Fi as the OBS computer. Open GloryCast Switch: it finds OBS on the Wi-Fi by itself.
  Type the OBS password once. If it can't find OBS: Settings > Find OBS on this Wi-Fi, or type the address.
- If Windows asks about the firewall for OBS, allow Private networks.

GloryCast Program scene (recommended for the stream)
- Settings > Stream > tick "Stream from one GloryCast Program scene". Switch makes a scene called GloryCast Program in OBS
  and puts every camera on your channels inside it. OBS streams a scene called GloryCast On Air, which only holds
  GloryCast Program, and Switch turns on OBS Studio Mode. Leave GloryCast On Air as it is.
- In OBS, add your logo, GloryCast Live display, lower thirds etc. ONCE at the top of GloryCast Program.
  They stay on screen whichever camera you tap live.
- Fades between cameras now work by themselves: pick Fade and a length on the phone, up to 20 seconds (or Other...).
  A camera tapped during a fade shows NEXT and goes live as soon as the fade ends.
  If you set Show Transition > Fade on the cameras in GloryCast Program before, set it back to None so CUT stays a clean cut.
- Fades are made by the phone only when "Stream from one GloryCast Program scene" is ticked. With it off, OBS itself
  decides, using the transition chosen in OBS.
- If fades cannot be made in your OBS, Settings shows "Fade not working in OBS (...)" with the reason, and the
  top line says "Fade off". Fades need OBS 28 or newer.
- If another scene gets sent live in OBS, the phone shows "OBS is off Program". Tap it to put Program back on air.

Adding things in OBS during the service
- Keep OBS in Studio Mode (the Studio Mode button under Controls). Switch turns it on with GloryCast Program and never turns it off.
  Clicking a scene in OBS then opens it on the left (Preview) to edit, and the stream does not change.
- Add your picture, video or slide to its scene there. To show it, tap that scene on the phone
  (if it has no channel yet: Settings > Arrange channels).
- Don't press OBS's Transition button: it puts OBS's Preview on the stream in place of the phone's cameras.
  If it happens, tap "OBS is off Program" on the phone.
- GloryCast Program and the camera showing in it are on the stream, so changes inside them show at once.
  Add new things there with the eye closed, then open the eye when they should be seen.
- Not using GloryCast Program? Turn on Studio Mode in OBS yourself. The phone keeps switching scenes, and after each
  switch OBS's Preview goes back to the scene you were editing.

Vertical stream (Aitum Vertical plugin): one switch for both
The phone switches GloryCast Program only. Put GloryCast Program inside your vertical scene once, and every camera you tap goes to the landscape and the vertical stream together.
1. Turn on GloryCast Program first (Settings on the phone > Stream), so the scene exists in OBS.
2. In the Aitum Vertical dock, make a new vertical scene, e.g. "GloryCast Program Vertical".
3. In that vertical scene click + > Scene > choose "GloryCast Program" > OK.
4. Right-click it > Transform > Fit to screen, then drag the sides (or hold Alt and drag to crop) so the speaker fills the upright frame.
5. Make that vertical scene the live one in the Aitum dock and leave it there during service.
Overlays: lower thirds and the Bible/hymn display in GloryCast Program come along too and can get cut off at the sides. For vertical, put those overlays in the vertical scene itself, above GloryCast Program, sized for the upright frame.

Low battery warning (GloryCast Cam phones)
- When a GloryCast Cam phone in OBS gets to 20% and is not charging, a warning shows across the top, for example
  "Battery low: Altar is at 15%. Tell that camera person to plug in a charger.", and that camera's channel shows
  a battery mark. Tap OK to hide it. It comes back in red at 10% and again at 5%, and clears once the phone is charging.
  An Android phone running Switch also buzzes.
- Nothing to set up: Switch finds the GloryCast Cam phones in your OBS scenes by itself.
  GloryCast Cam (1.3.2 or later) must be running on the media computer.
- Works for Android camera phones (the GloryCast Cam app or Chrome). An iPhone camera in Safari cannot share its battery.

Tips
- Make one OBS scene per camera (Camera 1, Camera 2, Wide...).
- Channels: 4x2 (8 channels) by default. Settings > Camera channels: 2x2, 3x2, 4x2, 3x3, 4x3 or 6x2 (across x down).
- Arrange channels: Settings > Arrange channels (or hold any channel). Tap a channel, pick its camera or Empty, tap DONE.
  The phone remembers your arrangement. Settings > OBS order puts them back.
- Layout: drag the little bar under Preview / Live (up = bigger cameras), or Settings > Layout: Big Preview / Live, Even, Big cameras.
- Picture speed: Saver for an older laptop, Smooth for a strong one (Settings shows pictures per second). The phone pictures are for choosing shots; the stream is not affected.
- Keep the phone screen awake while switching (phone settings > display timeout).
- On the laptop itself: keys 1-9 pick a camera, Enter = CUT, Space = AUTO.
