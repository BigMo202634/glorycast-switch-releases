@echo off
title GloryCast Switch
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0launch\serve.ps1"
