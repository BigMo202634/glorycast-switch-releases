# GloryCast Switch: tiny web server for Windows (no install, no admin needed).
# Phones on the same Wi-Fi open http://glorycast-switch.local:7790/ (or http://THIS-COMPUTER:7790/) to switch OBS cameras.
# The name link works because this script also answers "where is glorycast-switch.local?" on the Wi-Fi with this
# computer's address (multicast DNS, RFC 6762), so the link stays right when the computer's address changes.
# Written for Windows PowerShell 5.1: keep PowerShell 7-only syntax out.
param([int]$Port = 7790)
$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path (Join-Path $PSScriptRoot "..") "app")).Path
$types = @{ ".html"="text/html; charset=utf-8"; ".js"="text/javascript; charset=utf-8"; ".css"="text/css"; ".svg"="image/svg+xml";
            ".png"="image/png"; ".jpg"="image/jpeg"; ".ttf"="font/ttf"; ".json"="application/json"; ".ico"="image/x-icon" }
$utf8 = New-Object System.Text.UTF8Encoding($false)

$tcp = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Any, $Port)
try { $tcp.Start() } catch {
  # Already running (second double-click): just open the page.
  try { Start-Process "http://localhost:$Port/" } catch {}; exit
}
function LanAddresses {
  try {
    [System.Net.Dns]::GetHostAddresses([System.Net.Dns]::GetHostName()) |
      Where-Object { $_.AddressFamily -eq "InterNetwork" -and -not $_.ToString().StartsWith("127.") -and -not $_.ToString().StartsWith("169.254.") } |
      ForEach-Object { $_.ToString() }
  } catch { @() }
}

# The name responder: answers phones that ask (multicast DNS) where glorycast-switch.local is, with this computer's
# address. It runs in a background runspace because the web server loop below never returns.
$mdnsName = "glorycast-switch.local"
$mdnsScript = {
  param($udp, $name)
  $group = [System.Net.IPAddress]::Parse("224.0.0.251")
  function LanIps {
    try {
      [System.Net.Dns]::GetHostAddresses([System.Net.Dns]::GetHostName()) |
        Where-Object { $_.AddressFamily -eq "InterNetwork" -and -not $_.ToString().StartsWith("127.") -and -not $_.ToString().StartsWith("169.254.") }
    } catch { }
  }
  # Listen on every network this computer is on (again every minute, for a new or changed network).
  function JoinAll {
    $ips = @(LanIps); if ($ips.Count -eq 0) { $ips = @([System.Net.IPAddress]::Any) }
    foreach ($ip in $ips) { try { $udp.JoinMulticastGroup($group, $ip) } catch { } }
  }
  # This computer's address on the network a phone asked from (the first LAN address if that fails).
  function LocalFor($peer) {
    try {
      $t = New-Object System.Net.Sockets.Socket([System.Net.Sockets.AddressFamily]::InterNetwork, [System.Net.Sockets.SocketType]::Dgram, [System.Net.Sockets.ProtocolType]::Udp)
      try { $t.Connect($peer, 9); $ip = $t.LocalEndPoint.Address } finally { $t.Close() }   # sends nothing
      $txt = $ip.ToString()
      if (-not $txt.StartsWith("127.") -and -not $txt.StartsWith("0.")) { return $ip }
    } catch { }
    $all = @(LanIps); if ($all.Count -gt 0) { return $all[0] }
    return $null
  }
  # The DNS name at $b[$p] (following compression pointers) and the position just after it; $null if broken.
  function ReadName([byte[]]$b, [int]$p) {
    $labels = @(); $end = -1
    for ($i = 0; $i -lt 128; $i++) {
      if ($p -ge $b.Length) { return $null }
      $n = [int]$b[$p]
      if ($n -eq 0) { if ($end -lt 0) { $end = $p + 1 }; return @(($labels -join "."), $end) }
      if (($n -band 0xC0) -eq 0xC0) {
        if ($p + 1 -ge $b.Length) { return $null }
        if ($end -lt 0) { $end = $p + 2 }
        $p = ($n -band 0x3F) * 256 + [int]$b[$p + 1]
      } elseif ($n -lt 64 -and $p + 1 + $n -le $b.Length) {
        $labels += [System.Text.Encoding]::UTF8.GetString($b, $p + 1, $n)
        $p += 1 + $n
      } else { return $null }
    }
    return $null
  }
  function NameBytes([string]$n) {
    $out = New-Object System.Collections.Generic.List[byte]
    foreach ($l in $n.Split(".")) { $lb = [System.Text.Encoding]::UTF8.GetBytes($l); $out.Add([byte]$lb.Length); $out.AddRange($lb) }
    $out.Add([byte]0)
    return ,$out.ToArray()
  }
  function Answer([byte[]]$q, [System.Net.IPEndPoint]$from) {
    if ($q.Length -lt 12 -or ($q[2] -band 0xF8)) { return }   # a reply (QR bit), or not a standard query
    $p = 12
    $count = [int]$q[4] * 256 + [int]$q[5]
    for ($i = 0; $i -lt $count; $i++) {
      $r = ReadName $q $p
      if ($null -eq $r) { return }
      $qn = $r[0]; $p = $r[1]
      if ($p + 4 -gt $q.Length) { return }
      $qtype = [int]$q[$p] * 256 + [int]$q[$p + 1]
      $qclass = ([int]$q[$p + 2] * 256 + [int]$q[$p + 3]) -band 0x7FFF
      $question = [byte[]]($q[$p..($p + 3)])
      $p += 4
      # A (1) or ANY (255), class IN (1) or ANY (255); -ne ignores upper and lower case.
      if ($qn -ne $name -or ($qtype -ne 1 -and $qtype -ne 255) -or ($qclass -ne 1 -and $qclass -ne 255)) { continue }
      $ip = LocalFor $from.Address
      if ($null -eq $ip) { return }
      $m = New-Object System.Collections.Generic.List[byte]
      if ($from.Port -eq 5353) {
        # A multicast DNS asker: tell everyone (ID 0, no question), cache-flush, kept 2 minutes.
        $m.AddRange([byte[]](0, 0, 0x84, 0, 0, 0, 0, 1, 0, 0, 0, 0))
        $m.AddRange((NameBytes $name))
        $m.AddRange([byte[]](0, 1, 0x80, 1, 0, 0, 0, 120, 0, 4))
        $m.AddRange($ip.GetAddressBytes())
        $udp.Client.SetSocketOption([System.Net.Sockets.SocketOptionLevel]::IP, [System.Net.Sockets.SocketOptionName]::MulticastInterface, $ip.GetAddressBytes())
        $bytes = $m.ToArray()
        [void]$udp.Send($bytes, $bytes.Length, (New-Object System.Net.IPEndPoint($group, 5353)))
      } else {
        # A one-shot asker (legacy unicast): a plain DNS answer straight back, same ID, question repeated, 10 s.
        $nb = NameBytes $qn
        $m.Add($q[0]); $m.Add($q[1])
        $m.AddRange([byte[]](0x84, 0, 0, 1, 0, 1, 0, 0, 0, 0))
        $m.AddRange($nb); $m.AddRange($question)
        $m.AddRange($nb); $m.AddRange([byte[]](0, 1, 0, 1, 0, 0, 0, 10, 0, 4))
        $m.AddRange($ip.GetAddressBytes())
        $bytes = $m.ToArray()
        [void]$udp.Send($bytes, $bytes.Length, $from)
      }
      return
    }
  }

  & {
    try { [void]$udp.Client.IOControl(-1744830452, [byte[]](0, 0, 0, 0), $null) } catch { }   # Windows: a phone that left must not stop us
    try { $udp.Client.ReceiveTimeout = 5000 } catch { }
    try { $udp.Client.SetSocketOption([System.Net.Sockets.SocketOptionLevel]::IP, [System.Net.Sockets.SocketOptionName]::MulticastTimeToLive, 255) } catch { }
    try { $udp.Ttl = 255 } catch { }
    JoinAll; $joined = [DateTime]::UtcNow
    while ($true) {
      if (([DateTime]::UtcNow - $joined).TotalSeconds -ge 60) { JoinAll; $joined = [DateTime]::UtcNow }
      $from = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Any, 0)
      try { $data = $udp.Receive([ref]$from) } catch {
        $e = $_.Exception; if ($e.InnerException) { $e = $e.InnerException }
        if (-not ($e -is [System.Net.Sockets.SocketException] -and $e.SocketErrorCode -eq [System.Net.Sockets.SocketError]::TimedOut)) { Start-Sleep -Milliseconds 200 }
        continue
      }
      try { Answer $data $from } catch { }   # a strange packet or a network hiccup: keep answering
    }
  } | Out-Null
}
$mdns = $null
try {
  # Share port 5353 with Windows' own multicast DNS service.
  $udp = New-Object System.Net.Sockets.UdpClient
  try { $udp.ExclusiveAddressUse = $false } catch { }
  $udp.Client.SetSocketOption([System.Net.Sockets.SocketOptionLevel]::Socket, [System.Net.Sockets.SocketOptionName]::ReuseAddress, $true)
  $udp.Client.Bind((New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Any, 5353)))
  $mdnsRunspace = [RunspaceFactory]::CreateRunspace(); $mdnsRunspace.Open()
  $mdns = [PowerShell]::Create(); $mdns.Runspace = $mdnsRunspace
  $null = $mdns.AddScript($mdnsScript).AddArgument($udp).AddArgument($mdnsName)
  $null = $mdns.BeginInvoke()
} catch {   # the name link is a bonus: the number link works without it
  $mdns = $null
  if ($udp) { try { $udp.Close() } catch { } }
}

Write-Host "GloryCast Switch is running."
$lan = @(LanAddresses)
if ($mdns) {
  Write-Host "  On your phone (same Wi-Fi) open:  http://${mdnsName}:$Port/"
  for ($n = 0; $n -lt $lan.Count; $n++) {
    $lead = "                                    "; if ($n -eq 0) { $lead = "  If that does not open, use:       " }
    Write-Host ($lead + "http://" + $lan[$n] + ":$Port/")
  }
} else {
  foreach ($ip in $lan) { Write-Host "  On your phone (same Wi-Fi) open:  http://${ip}:$Port/" }
  Write-Host "  (The name link http://${mdnsName}:$Port/ is not available on this computer right now.)"
}
Write-Host "Leave this window open during service. Close it to stop."
Write-Host "If Windows asks about the firewall, allow Private networks."
try { Start-Process "http://localhost:$Port/" } catch {}

function Send-Bytes($stream, [byte[]]$bytes) { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush() }
function Reply($stream, [int]$code, [string]$type, [byte[]]$body) {
  $status = @{ 200 = "OK"; 404 = "Not Found" }[$code]
  $head = "HTTP/1.1 $code $status`r`nContent-Type: $type`r`nContent-Length: $($body.Length)`r`nCache-Control: no-cache`r`nConnection: close`r`n`r`n"
  Send-Bytes $stream $utf8.GetBytes($head)
  if ($body.Length) { Send-Bytes $stream $body }
}

while ($true) {
  $client = $tcp.AcceptTcpClient()
  try {
    $s = $client.GetStream(); $s.ReadTimeout = 3000
    $reader = New-Object System.IO.StreamReader($s, $utf8, $false, 1024, $true)
    $first = $reader.ReadLine()
    while ($true) { $l = $reader.ReadLine(); if ($l -eq $null -or $l -eq "") { break } }
    if ($first) {
      $url = ($first -split " ")[1]; $q = $url.IndexOf("?"); if ($q -ge 0) { $url = $url.Substring(0, $q) }
      $path = [Uri]::UnescapeDataString($url.TrimStart("/"))
      if ($path -eq "") { $path = "index.html" }
      if ($path -eq "__info") {
        $ips = @(LanAddresses) | ForEach-Object { '"' + $_ + '"' }
        $nameField = ""; if ($mdns) { $nameField = ',"name":"' + $mdnsName + '"' }
        Reply $s 200 "application/json" $utf8.GetBytes('{"port":' + $Port + ',"ips":[' + ($ips -join ",") + ']' + $nameField + '}')
      } else {
        $file = [IO.Path]::GetFullPath((Join-Path $root $path))
        if (-not $file.StartsWith($root) -or -not (Test-Path $file -PathType Leaf)) { Reply $s 404 "text/plain" $utf8.GetBytes("Not found") }
        else {
          $type = $types[[IO.Path]::GetExtension($file).ToLower()]; if (-not $type) { $type = "application/octet-stream" }
          Reply $s 200 $type ([IO.File]::ReadAllBytes($file))
        }
      }
    }
  } catch { }
  try { $client.Close() } catch {}
}
