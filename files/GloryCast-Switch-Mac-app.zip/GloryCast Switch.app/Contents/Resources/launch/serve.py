#!/usr/bin/env python3
"""GloryCast Switch: tiny web server (Mac, Linux, or Windows with Python).
Phones on the same Wi-Fi open http://glorycast-switch.local:7790/ (or http://THIS-COMPUTER:7790/) to switch OBS cameras.
The name link works because this server also answers "where is glorycast-switch.local?" on the Wi-Fi with this
computer's address (multicast DNS, RFC 6762), so the link stays right when the computer's address changes."""
import functools, http.server, json, os, socket, struct, subprocess, sys, threading, time, urllib.request, webbrowser

VERSION = "1.4.1"  # the Mac app compares this to replace an older Switch still running
ARGS = [a for a in sys.argv[1:] if not a.startswith("--")]
PORT = int(ARGS[0]) if ARGS else 7790
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app")
NAME = "glorycast-switch.local"
MDNS_GROUP, MDNS_PORT = "224.0.0.251", 5353
mdns_running = False


def lan_addresses():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1)); ips.add(s.getsockname()[0]); s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    return sorted(ip for ip in ips if not ip.startswith(("127.", "169.254.")))


def local_ip_for(peer):
    """This computer's address on the network a phone asked from (the first LAN address if that fails)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect((peer, 9))  # sends nothing: only picks the way out to that phone
            ip = s.getsockname()[0]
        finally:
            s.close()
        if not ip.startswith(("127.", "0.")):
            return ip
    except OSError:
        pass
    ips = lan_addresses()
    return ips[0] if ips else None


def read_name(msg, p):
    """The DNS name at msg[p] (following compression pointers) and the position just after it."""
    labels, end = [], None
    for _ in range(128):
        n = msg[p]
        if n == 0:
            return ".".join(labels), (end if end is not None else p + 1)
        if n & 0xC0 == 0xC0:
            if end is None:
                end = p + 2
            p = (n & 0x3F) << 8 | msg[p + 1]
        elif n < 64 and p + 1 + n <= len(msg):
            labels.append(msg[p + 1:p + 1 + n].decode("utf-8", "replace"))
            p += 1 + n
        else:
            raise ValueError("bad name")
    raise ValueError("name loops")


def dns_name(name):
    return b"".join(bytes([len(b)]) + b for b in (label.encode("utf-8") for label in name.split("."))) + b"\0"


class NameResponder(threading.Thread):
    """Answers phones that ask (multicast DNS) where glorycast-switch.local is, with this computer's address."""

    def __init__(self):
        super().__init__(daemon=True)
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        try:
            # Share port 5353 with the computer's own multicast DNS service (always running on a Mac).
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            if hasattr(socket, "SO_REUSEPORT"):
                try:
                    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
                except OSError:
                    pass
            s.bind(("", MDNS_PORT))
            s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 255)
            try:
                s.setsockopt(socket.IPPROTO_IP, socket.IP_TTL, 255)
            except OSError:
                pass
            s.settimeout(5)
        except OSError:
            s.close()
            raise
        self.sock = s
        self.join_groups()

    def join_groups(self):  # not Thread.join
        """Listen on every network this computer is on (again every minute, for a new or changed network)."""
        for ip in lan_addresses() or ["0.0.0.0"]:
            try:
                self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, socket.inet_aton(MDNS_GROUP) + socket.inet_aton(ip))
            except OSError:
                pass  # already listening there, or that network has gone

    def run(self):
        joined = time.monotonic()
        while True:
            if time.monotonic() - joined > 60:
                self.join_groups()
                joined = time.monotonic()
            try:
                msg, peer = self.sock.recvfrom(9000)
            except socket.timeout:
                continue
            except OSError:
                time.sleep(1)
                continue
            try:
                self.answer(msg, peer)
            except Exception:
                pass  # a strange packet or a network hiccup: keep answering

    def answer(self, q, peer):
        if len(q) < 12 or q[2] & 0xF8:  # a reply (QR bit), or not a standard query
            return
        p = 12
        for _ in range(q[4] << 8 | q[5]):
            name, p = read_name(q, p)
            if p + 4 > len(q):
                return
            qtype, qclass, question = q[p] << 8 | q[p + 1], (q[p + 2] << 8 | q[p + 3]) & 0x7FFF, q[p:p + 4]
            p += 4
            if name.lower() != NAME or qtype not in (1, 255) or qclass not in (1, 255):  # A or ANY, class IN or ANY
                continue
            ip = local_ip_for(peer[0])
            if not ip:
                return
            if peer[1] == MDNS_PORT:  # a multicast DNS asker: tell everyone, cache-flush, kept 2 minutes
                reply = (struct.pack("!6H", 0, 0x8400, 0, 1, 0, 0) + dns_name(NAME)
                         + struct.pack("!HHIH", 1, 0x8001, 120, 4) + socket.inet_aton(ip))
                self.sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(ip))
                self.sock.sendto(reply, (MDNS_GROUP, MDNS_PORT))
            else:  # a one-shot asker (legacy unicast): a plain DNS answer straight back, same ID, question repeated
                qn = dns_name(name)
                reply = (q[:2] + struct.pack("!5H", 0x8400, 1, 1, 0, 0) + qn + question
                         + qn + struct.pack("!HHIH", 1, 1, 10, 4) + socket.inet_aton(ip))
                self.sock.sendto(reply, peer)
            return


class Handler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()

    def do_GET(self):
        if self.path.split("?")[0] == "/__info":
            info = {"port": PORT, "ips": lan_addresses(), "version": VERSION, "stop": True}
            if mdns_running:
                info["name"] = NAME
            body = json.dumps(info).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
            return
        super().do_GET()

    def do_POST(self):
        """POST /__quit stops Switch: only from this computer, and only from Switch's own page (or no page at all)."""
        if self.path.split("?")[0] != "/__quit":
            self.send_error(404); return
        origin = self.headers.get("Origin", "")
        local = self.client_address[0] in ("127.0.0.1", "::1", "::ffff:127.0.0.1")
        page_ok = origin in ("", f"http://localhost:{PORT}", f"http://127.0.0.1:{PORT}")
        if not (local and page_ok):
            self.send_error(403); return
        body = b'{"ok":true}'
        self.send_response(200); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
        threading.Thread(target=self.server.shutdown, daemon=True).start()


def running_info():
    """What a Switch already running on this computer says about itself (None if none answers)."""
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/__info", timeout=2) as r:
            return json.loads(r.read().decode() or "{}")
    except Exception:
        return None


def start_for_app():
    """The Mac app runs `serve.py --app`: Switch starts in the background (no Terminal window), the page opens in
    the web browser, and this exits. Opening the app again only opens the page; a different version is replaced.
    A message printed here (exit 1) is shown to the user by the app."""
    url = f"http://localhost:{PORT}/"
    info = running_info()
    if info is not None and info.get("version") == VERSION:
        webbrowser.open(url); return
    if info is not None:
        try:
            req = urllib.request.Request(f"http://127.0.0.1:{PORT}/__quit", data=b"", method="POST")
            urllib.request.urlopen(req, timeout=2).read()
        except Exception:
            print("An older GloryCast Switch is still running in a Terminal window. Close that window, then open GloryCast Switch again.")
            sys.exit(1)
        for _ in range(25):
            if running_info() is None:
                break
            time.sleep(0.2)
    home = os.path.join(os.path.expanduser("~"), ".glorycast-switch")
    os.makedirs(home, exist_ok=True)
    log = open(os.path.join(home, "server.log"), "ab")
    subprocess.Popen([sys.executable, os.path.abspath(__file__), str(PORT), "--no-browser"], stdin=subprocess.DEVNULL,
                     stdout=log, stderr=log, cwd=home, start_new_session=True)
    for _ in range(50):
        time.sleep(0.2)
        if running_info() is not None:
            webbrowser.open(url); return
    print(f"GloryCast Switch could not start. Is another program using port {PORT}? Details: {os.path.join(home, 'server.log')}")
    sys.exit(1)


if __name__ == "__main__" and "--app" in sys.argv:
    start_for_app(); sys.exit(0)

if __name__ == "__main__":
    http.server.ThreadingHTTPServer.allow_reuse_address = True
    try:
        srv = http.server.ThreadingHTTPServer(("0.0.0.0", PORT), functools.partial(Handler, directory=ROOT))
    except OSError:
        webbrowser.open(f"http://localhost:{PORT}/"); sys.exit(0)
    try:  # the name link is a bonus: the number link works without it
        NameResponder().start()
        mdns_running = True
    except Exception:
        pass
    print("GloryCast Switch is running.")
    ips = lan_addresses()
    if mdns_running:
        print(f"  On your phone (same Wi-Fi) open:  http://{NAME}:{PORT}/")
        for i, ip in enumerate(ips):
            print(("  If that does not open, use:       " if i == 0 else "                                    ") + f"http://{ip}:{PORT}/")
        if sys.platform == "darwin":
            print("If the Mac asks to let it find devices on your local network, click Allow.")
    else:
        for ip in ips:
            print(f"  On your phone (same Wi-Fi) open:  http://{ip}:{PORT}/")
        print(f"  (The name link http://{NAME}:{PORT}/ is not available on this computer right now.)")
    print("Leave this window open during service. Close it to stop.")
    if "--no-browser" not in sys.argv:
        webbrowser.open(f"http://localhost:{PORT}/")
    srv.serve_forever()
